package vn.edu.socialplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialplatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialplatformApplication.class, args);
	}

}
